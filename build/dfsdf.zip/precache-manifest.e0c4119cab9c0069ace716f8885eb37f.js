self.__precacheManifest = [
  {
    "revision": "bf05d21100f9b3474e25",
    "url": "https://prod.bayofstyle.com/static/css/main.282705a6.chunk.css"
  },
  {
    "revision": "bf05d21100f9b3474e25",
    "url": "https://prod.bayofstyle.com/static/js/main.bf05d211.chunk.js"
  },
  {
    "revision": "defd498316c85a206595",
    "url": "https://prod.bayofstyle.com/static/js/runtime~main.defd4983.js"
  },
  {
    "revision": "74eecce7855932c3cbc1",
    "url": "https://prod.bayofstyle.com/static/css/2.58485ae1.chunk.css"
  },
  {
    "revision": "74eecce7855932c3cbc1",
    "url": "https://prod.bayofstyle.com/static/js/2.74eecce7.chunk.js"
  },
  {
    "revision": "15b849d17e1c683409ade55ebecb9993",
    "url": "https://prod.bayofstyle.com/index.html"
  }
];