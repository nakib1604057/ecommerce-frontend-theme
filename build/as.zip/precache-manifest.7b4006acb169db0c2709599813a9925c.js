self.__precacheManifest = [
  {
    "revision": "e7f9b19b51d12e726976",
    "url": "https://bayofstyle.com/static/css/main.566ece8f.chunk.css"
  },
  {
    "revision": "e7f9b19b51d12e726976",
    "url": "https://bayofstyle.com/static/js/main.e7f9b19b.chunk.js"
  },
  {
    "revision": "a68bfcb76c02d95da876",
    "url": "https://bayofstyle.com/static/js/runtime~main.a68bfcb7.js"
  },
  {
    "revision": "d45d0277aa9f8bce0787",
    "url": "https://bayofstyle.com/static/css/2.3ee90ff3.chunk.css"
  },
  {
    "revision": "d45d0277aa9f8bce0787",
    "url": "https://bayofstyle.com/static/js/2.d45d0277.chunk.js"
  },
  {
    "revision": "bd29388c125c9c94ab981f20f9050a55",
    "url": "https://bayofstyle.com/index.html"
  }
];